from django.shortcuts import render, get_object_or_404
from .models import Education

# Create your views here.
def e_detail(request, edu_id):
    edu_detail = get_object_or_404(Education, pk = edu_id)
    return render(request, 'educations/e_detail.html', {'education': edu_detail})
