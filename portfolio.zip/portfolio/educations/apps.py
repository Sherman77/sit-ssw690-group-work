from django.apps import AppConfig


class EducationsConfig(AppConfig):
    name = 'educations'
