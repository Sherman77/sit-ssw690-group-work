from django.apps import AppConfig


class JobsConfig(AppConfig):
    name = 'jobs'
